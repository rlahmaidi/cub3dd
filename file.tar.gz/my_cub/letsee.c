int main ()
{
    int rac,
    ana, 
    anaaaa
    anawhowa
    leet 
    leet
}
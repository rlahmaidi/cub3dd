#ifndef KEY_H
# define KEY_H

# define EVENT_KEYDOWN 2
# define EVENT_KEYUP 3
# define EVENT_EXIT 17
# define EXIT_SUCCESS 0
# define KEY_A 97
# define KEY_S 115
# define KEY_D 100
# define KEY_W 119
# define KEY_LEFT 65361
# define KEY_RIGHT 124
# define KEY_DOWN 125
# define KEY_UP 65362
# define ESC_KEY 53

#endif